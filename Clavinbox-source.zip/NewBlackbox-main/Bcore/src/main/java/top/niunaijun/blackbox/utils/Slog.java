

package top.niunaijun.blackbox.utils;

import android.util.Log;


public final class Slog {
     public static final int LOG_ID_SYSTEM = 3;

    private Slog() {
    }

    // Verbose/debug/info no longer write to the per-app file by default — across a
    // multi-hour cumulative session this was a continuous, never-ending stream of file
    // I/O (one open+append+close per call, potentially thousands of times a minute),
    // which is real overhead on a resource-constrained device and a plausible
    // contributor to "gets worse the longer you play". Now that the main crash causes
    // have been pinned down from the data this already collected, routine logging only
    // needs to catch warnings, errors, and fatal crashes going forward — all of which
    // still write to the file exactly as before. logcat output (Log.println) is
    // unaffected either way.
    public static int v(String tag, String msg) {
        return Log.println(Log.VERBOSE, tag, msg);
    }

    public static int v(String tag, String msg, Throwable tr) {
        return Log.println(Log.VERBOSE, tag,
                msg + '\n' + Log.getStackTraceString(tr));
    }

    
    public static int d(String tag, String msg) {
        return Log.println(Log.DEBUG, tag, msg);
    }

    
    public static int d(String tag, String msg, Throwable tr) {
        return Log.println(Log.DEBUG, tag,
                msg + '\n' + Log.getStackTraceString(tr));
    }

    
    public static int i(String tag, String msg) {
        return Log.println(Log.INFO, tag, msg);
    }

    public static int i(String tag, String msg, Throwable tr) {
        return Log.println(Log.INFO, tag,
                msg + '\n' + Log.getStackTraceString(tr));
    }

    
    public static int w(String tag, String msg) {
        FileLogger.append("W", tag, msg);
        return Log.println(Log.WARN, tag, msg);
    }

    
    public static int w(String tag, String msg, Throwable tr) {
        FileLogger.append("W", tag, msg + '\n' + Log.getStackTraceString(tr));
        return Log.println(Log.WARN, tag,
                msg + '\n' + Log.getStackTraceString(tr));
    }

    public static int w(String tag, Throwable tr) {
        FileLogger.append("W", tag, Log.getStackTraceString(tr));
        return Log.println(Log.WARN, tag, Log.getStackTraceString(tr));
    }

    
    public static int e(String tag, String msg) {
        FileLogger.append("E", tag, msg);
        return Log.println(Log.ERROR, tag, msg);
    }

    
    public static int e(String tag, String msg, Throwable tr) {
        FileLogger.append("E", tag, msg + '\n' + Log.getStackTraceString(tr));
        return Log.println(Log.ERROR, tag,
                msg + '\n' + Log.getStackTraceString(tr));
    }

    public static int println(int priority, String tag, String msg) {
        if (priority >= Log.WARN) {
            FileLogger.append(String.valueOf(priority), tag, msg);
        }
        return Log.println(priority, tag, msg);
    }
}

